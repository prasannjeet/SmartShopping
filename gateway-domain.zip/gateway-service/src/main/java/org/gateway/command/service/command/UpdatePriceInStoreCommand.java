package org.gateway.command.service.command;

public class UpdatePriceInStoreCommand {

}
