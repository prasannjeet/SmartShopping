package org.gateway.command.service.command;

public class AddProductInStoreCommand implements GatewayCommand {

}
