package org.gateway.command.service.command;

import io.eventuate.Command;

public interface GatewayCommand extends Command {

}
